package com.mycompany.a1;

public abstract class Fixed extends GameObject  {
	
	// constructor
	public Fixed(int size, float x, float y) {
		super(size, x, y);
	}
}
